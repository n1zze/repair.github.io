Manrope is an open-source modern sans-serif font family, designed by Mikhail Sharanda in 2018. In 2019, Mirko Velimirovic worked with Mikhail Sharanda to convert Manrope into a variable font.

To contribute, see [github.com/sharanda/manrope](https://github.com/sharanda/manrope).